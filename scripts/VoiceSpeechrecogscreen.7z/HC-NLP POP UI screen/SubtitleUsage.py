import Subtitling

subtitler = Subtitling.Subtitling()
opFolder, audioLen, frameLen = subtitler.convertAudio(ffmpegPath = "D:/INSTALLED SOFTWARE/ANACONDA/ffmpeg-3.3.3-win64-static/bin/ffmpeg.exe",audioPath = "d:/RECORDING.wav",requiredFormat = 'mp3',outputFolder = "d:/")

#data = subtitler.recordSaveAudio("myrecord")

#subtitler.directCallGoogleSpeech(data)

#subtitler.convertToText(data)

print(opFolder, audioLen, frameLen)