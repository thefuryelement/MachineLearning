var app = angular.module('myApp', []);

app.controller('myCtrl', function($scope, $http) {

	$scope.clickme=function()
	{
		$http({
				method: 'GET',
				url: angular.element('#urlSearch').val(),
			}).then(function successCallback(response) 
					{
						$scope.Details = response.data.results;
						console.log($scope.Details);
					}, 
					
					function errorCallback(response) 
					{
						$scope.ResponseDetails = response;
					});
	}
});

var speechRecognizer = new webkitSpeechRecognition();


$(document).ready(function(){
	
	
	$(".submit").click(function(event){
		$("#backgroundSubscribePopup").css({"display": "block", "opacity": "0.5"});
		$(".hotelsDetails").show();
		event.stopPropagation();
	})

	$(".hotelsDetails").click(function(){
		event.stopPropagation();
	})
 
	$(this).click(function(){
		$("#backgroundSubscribePopup").css({"display": "none", "opacity": "0"});
		$(".hotelsDetails").hide();
	})
 
	$(".micro").click(function(){
		$(this).children().attr('src','microphone_hear.png');
	})

	$(".clearButton").click(function(){
		location.reload();
/*		$("#urlSearch").prop("disabled", false);
		$("#urlSearch").val('');
		$("#url").val('');
		$("#userSearch").val('');
		speechRecognizer.stop();
		document.getElementById('micSearch').src = "microphone.png";		
*/	});

	$("#LUISbutton").click(function(){
		var userQuery = $("#userSearch").val()
		var params = {"subscription-key" : "370c52eae9ca4c2cbb2a6995d464b1ef","q":userQuery,"timezoneOffset": "0.0","verbose": "true"};
		$.ajax({
			url: "https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/00cc8580-d375-4b4e-80ed-384f2b589561?" + $.param(params),
			beforeSend: function(xhrObj){
				xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key","370c52eae9ca4c2cbb2a6995d464b1ef");
			},
			type: "GET",
			data: "{"+userQuery+"}",
			success: function(json) {
				$("#query").html("Query: " + json.query);
				$("#intent").html("Intent: " + json.topScoringIntent["intent"]);					
				if(json.topScoringIntent["intent"] == "search hotel")
				{
					dataList = {
									"apiKey" : "E8FD07AA-BAD8-4862-BE20-BC33F9284BD1",
									"sessionID" : "1D2F",
									"destination": "place:UNKNOWN",
									"onlyIfComplete": "true"
								}
					console.log(json.entities)

					var searchIntents = '';
					for(var e=0; e<json.entities.length;e++)
					{
						if(json.entities[e]["type"].includes("geography")){	etype = "destination";	}
						else{	etype = json.entities[e]["type"]	}
						switch(etype)
						{
							case "destination": dataList["destination"]="place:"+json.entities[e]["entity"]; searchIntents = searchIntents+etype+" -> "+json.entities[e]["entity"]+"\n";break;
							case "StarRating": dataList["StarRating"]=json.entities[e]["entity"].split(" ")[0]; searchIntents = searchIntents+etype+" -> "+json.entities[e]["entity"]+"\n";break;
							case "builtin.datetime.date": if(!dataList["checkin"]){dataList["checkin"]=json.entities[e]["resolution"]["date"];searchIntents = searchIntents+"Checkin Date -> "+json.entities[e]["entity"]+"\n"; break}
							else{dataList["checkout"]=json.entities[e]["resolution"]["date"]; searchIntents = searchIntents+"Checkout Date -> "+json.entities[e]["entity"]+"\n";break};
							case "room": dataList["rooms"] = json.entities[e]["entity"].match(/\d+/);searchIntents = searchIntents+etype+" -> "+json.entities[e]["entity"]+"\n"; break;
							case "User Rating": dataList["guestRatings"]="8";searchIntents = searchIntents+etype+" -> "+json.entities[e]["entity"]+"\n"; break;
						}
					}
					if(dataList["destination"])
					{
						multiple_hotel_search_url = "https://169598.api.hotelscombined.com/api/2.0/hotels"
						var hcurl = '';
					/*	if(!dataList["checkout"]&&!dataList["checkin"]!="")
						{
							cdate = dataList["checkin"].split('-');
							dataList["checkout"] = cdate[0]+'-'+cdate[1]+'-'+(parseInt(cdate[2])+1).toString();
						}*/
						for( var link in dataList)
						{
							hcurl = hcurl+link+'='+dataList[link]+'&'
						}
						$("#url").text(searchIntents);
						$("#urlSearch").text(multiple_hotel_search_url+'?'+encodeURI(hcurl.substring(0,hcurl.length - 1)));
						$("#urlSearch").text();
						$("#urlSearch").prop("disabled", true);
						$( "#finalSearch" ).trigger( "click" );
				}
					else
					{
						$("#url").text("Sorry, no destination specified");						
					}
				}
				else { 
					//alert("Sorry, your input does not match 'Search Hotel'");
					$("#url").text("Sorry, your input does not match 'Search Hotel'");
				}

			},
			error: function(error) {
				$("#Result").html('Error: ' + error.message);
			}
		});
		
	})

	$("#micSearch").click(function(){

		var suffix = 'comment_like_123456'.match(/\d+/)
		console.log(suffix);
		var r = document.getElementById('userSearch');
			if('webkitSpeechRecognition' in window)
			{
				speechRecognizer.continuous = false;
				speechRecognizer.interimResults = false;
				speechRecognizer.lang = 'en-IN';
				speechRecognizer.start();
				var finalTranscripts = '';
				speechRecognizer.onresult = function(event)
				{
					console.log("onresult")
					var interimTranscripts = '';
					for(var i =event.resultIndex; i<event.results.length; i++)
					{
						
						var transcript = event.results[i][0].transcript;
						
						transcript.replace("\n","<br>");
						if(event.results[i].isFinal)
						{
							finalTranscripts += transcript;
						}
						else
						{
							interimTranscripts += transcript;
						}
					}
					clearTimeout(timer);
					$("#userSearch").val(finalTranscripts+interimTranscripts);
					var timer = setTimeout(function(){ speechRecognizer.stop(); console.log("speech ends, speechRecognizer stopped ") }, 4000);
					document.getElementById('micSearch').src = "microphone.png";
					$("#LUISbutton").click();
				};
				
				speechRecognizer.onerror = function(event)
				{
					console.log("some error occured");
				}
				speechRecognizer.onspeechend = function(event)
				{
					console.log("speech end");
				}
				speechRecognizer.onsoundend = function(event)
				{
					console.log("sound end");
				}
				speechRecognizer.onaudioend = function(event)
				{
					console.log("audio end");
				}
				
			}
			else
			{
				r.innerHTML = "Browsr is not supported";
			}		
	})
});

