'''
Created by Nitin Panwar on 25/09/2017 : The class created here allows the user to convert mp3, wav and flac files to
                                        required format. The readBytesInAudio() helps to retrieve bytes raw data from
                                        audio file. An instance of AudioData is created from the bytes and is sent to
                                        convertToText() method which calls google's Speech API.
                                        A native method directCallGoogleSpeech() has also been defined in case you don't
                                        want to call the googles speech api. It sends you voice data directly to the end
                                        point and returns a json for the transcript generated. Please feel free to update
                                        the code.
Note : The code is created for the purpose of research and must not be utilized for commercial purpose.
Prerequisites :
    Install ffmpeg and note path to ffmpeg.exe
    Pip install AudioSegment
    Pip install SpeechRecognition
    Pip install PyAudio
'''
import wave
import speech_recognition as sr
from pydub import AudioSegment
import pyaudio
import time
from urllib.request import Request, urlopen
from urllib.parse import urlencode
import matplotlib.pyplot as plt

class Subtitling():

    def __init__(self):
        self.recognizer = sr.Recognizer()

    #--------------------------------------------------
    # TO CONVERT FILE TO SPECIFIC FORMAT
    #--------------------------------------------------
    def convertAudio(self,ffmpegPath, audioPath, outputFolder, requiredFormat='wav'):
        # Giving temporary path for ffmpeg
        AudioSegment.ffmpeg = ffmpegPath
        waveInfo = AudioSegment.from_file(file=audioPath)
        print(waveInfo.rms)
        print(waveInfo.dBFS)
        print(waveInfo.max)
        print(waveInfo.max_possible_amplitude)
        print(waveInfo.duration_seconds)
        print(waveInfo.frame_count())
        waveInfo.export(outputFolder+"newFile."+requiredFormat, format=requiredFormat)
        return outputFolder+"convertedFile."+requiredFormat, waveInfo.duration_seconds, waveInfo.frame_count()
    #--------------------------------------------------
    # NATIVE CALL TO GOOGLE URL FOR SPEECH CONVERSION
    #--------------------------------------------------
    def directCallGoogleSpeech(self, audio_data):
        key = "AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw"
        flac_data = audio_data.get_flac_data(
            convert_rate=None if audio_data.sample_rate >= 8000 else 8000,  # audio samples must be at least 8 kHz
            convert_width=2  # audio samples must be 16-bit
        )
        language = 'en'
        url = "http://www.google.com/speech-api/v2/recognize?{}".format(urlencode({
            "client": "chromium",
            "lang": language,
            "key": key,
        }))
        request = Request(url, data=flac_data, headers={"Content-Type": "audio/x-flac; rate={}".format(audio_data.sample_rate)})

        try:
            response = urlopen(request)
        except HTTPError as e:
            raise RequestError("recognition request failed: {}".format(e.reason))
        except URLError as e:
            raise RequestError("recognition connection failed: {}".format(e.reason))
        response_text = response.read().decode("utf-8")
        print(response_text)

    #--------------------------------------------------
    # TO CONVERT SPEECH TO TEXT USING GOOGLE SPEECH API
    #--------------------------------------------------
    def convertToText(self, audioByteData):
        if isinstance(audioByteData, sr.AudioData):
            recognizer = sr.Recognizer()
            try:
                print("You said: " + recognizer.recognize_google(audioByteData, language='en'))
            except sr.UnknownValueError:
                print("unknown error")
            except sr.RequestError as e:
                print("Request Error {}".format(e))
        else:
            raise Exception("Must be Instance of AudioDaTa")


    #--------------------------------------------------
    # TO READ AUDIO FILE AND RETURN RAW BYTES
    #--------------------------------------------------
    def readBytesInAudio(self, sampleRate = 48000, sampleWidth=2):
        # Need to read the audio file as bytes information
        bytesDataFromAudio= open("d:/nfile.wav", 'rb')
        # create AudioData class instance as google speech recognizer doesn't take any other format.
        audioDataObject = sr.AudioData(bytesDataFromAudio.read(), sample_rate=sampleRate, sample_width=sampleWidth)
        return audioDataObject


    #--------------------------------------------------
    # TO RECORD AND SAVE YOUR OWN AUDIO FILE
    #--------------------------------------------------
    def recordSaveAudio(self, newAudioFileName):
        with sr.Microphone(device_index = 0, sample_rate = 48000,chunk_size = 1024) as source:
            print("Listening")
            audFile = self.recognizer.listen(source)
            frames = audFile.get_raw_data()
            with open("d:/"+newAudioFileName, "wb") as f:
                f.write(frames)
        return audFile

    #--------------------------------------------------
    # TO PLOT SOUND IN AUDIO FILE
    #--------------------------------------------------
    def plotAudioSignal(self, audioDataFile):
        '''
        Code to check the voice rms and fluctuation in order to detect the voices in the audio file.
        Please plot "rms to time", "max to time" and "DBFS to time" : all the three values are extracted from convertAudio() method
        in the class Subtitling.
        '''
        pass