'''
Created on Feb 15, 2017

@author: sachindesh
'''
import requests
from urllib.parse import urlencode
#apiKey=E8FD07AA-BAD8-4862-BE20-BC33F9284BD1

ping_url1 = "https://169598.api.hotelscombined.com/api/2.0/ping"
multiple_hotel_search_url = "https://169598.api.hotelscombined.com/api/2.0/hotels"
user_agent = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; hu-HU; rv:1.7.8) Gecko/20050511 Firefox/1.0.4'}
dataList = {
            "apiKey" : "E8FD07AA-BAD8-4862-BE20-BC33F9284BD1",
            "sessionID" : "1D2F",
            "destination": "place:Pune",
            "checkin": "2017-03-01",
            "checkout": "2017-03-02",
            "rooms": "1",
            "isComplete": "true"
            } 

"""
    Convert Dictionary to Query String:
        queryString = urlencode(dataList)
        print("Query String=", queryString)
        E.g.   sessionID=1D2F&apiKey=E8FD07AA-BAD8-4862-BE20-BC33F9284BD1
"""

queryString = urlencode(dataList)
print("Query String=", queryString)

response = requests.get( multiple_hotel_search_url, params=dataList, headers = user_agent)

print("Status code=", response.status_code)
print("Headers=", response.headers)
print("Body Text=", response.text)